OK_FORMAT = True

test = {   'name': 'q4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert 0 < p_value_solar < 0.01\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert bool(reject_solar) == True\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
