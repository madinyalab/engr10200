OK_FORMAT = True

test = {   'name': 'q5',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert len(ci95) == 2\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(ci95[0], 4.16, atol=0.03) and np.isclose(ci95[1], 4.84, atol=0.03)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert bool(new_inside) == False\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
