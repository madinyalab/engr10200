OK_FORMAT = True

test = {   'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert len(simulated_means) == 10000\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(simulated_means.mean(), 4.5, atol=0.02)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(simulated_means.std(), 0.6 / np.sqrt(12), atol=0.015)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
