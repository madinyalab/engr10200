OK_FORMAT = True

test = {   'name': 'q8',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> assert np.isclose(var_a, 2.239, atol=0.01) and np.isclose(var_b, 16.02, atol=0.05)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(sp2, 5.949, atol=0.01) and np.isclose(SE, 1.02, atol=0.005)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(t_stat, -2.352, atol=0.005) and df_student == 26\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
