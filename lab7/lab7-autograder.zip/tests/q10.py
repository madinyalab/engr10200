OK_FORMAT = True

test = {   'name': 'q10',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert np.isclose(welch_result.pvalue, 0.138, atol=0.002)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(welch_result.df, 7.8, atol=0.02)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
