OK_FORMAT = True

test = {   'name': 'q1_6',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert np.isclose(new_mean_4, 4.82, atol=0.005)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert len(simulated_means_4) == 10000\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert 0.1 < p_value_4 < 0.2\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
