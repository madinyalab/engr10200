OK_FORMAT = True

test = {   'name': 'q1_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert len(standard) == 300 and len(new) == 12\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(standard_mean, 4.5, atol=0.005) and np.isclose(standard_std, 0.6, atol=0.005)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(new_mean, 4.955, atol=0.005)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
