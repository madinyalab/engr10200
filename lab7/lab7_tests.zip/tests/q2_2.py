OK_FORMAT = True

test = {   'name': 'q2_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert np.isclose(t_crit, 2.056, atol=0.002)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert bool(reject_student) == True\n', 'hidden': False, 'locked': False},
                                   {   'code': '>>> assert np.isclose(student_result.statistic, t_stat, atol=1e-06) and np.isclose(student_result.pvalue, 0.0265, atol=0.001)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
