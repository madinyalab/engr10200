OK_FORMAT = True

test = {   'name': 'q3_1',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> assert np.isclose(observed_diff, 1.79, atol=0.005)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert len(shuffled_diffs) == 10000\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert 0.02 < p_perm < 0.05\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
